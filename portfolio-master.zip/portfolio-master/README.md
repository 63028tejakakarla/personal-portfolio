# Portfolio
<!-- <img src="TejasPicture.jpeg" height="100" width="100"> -->
<!-- ![](TejasPicture.jpeg) -->





https://user-images.githubusercontent.com/107451256/187974301-6f0d0236-428a-485f-a9e7-c900f2aae062.mp4

